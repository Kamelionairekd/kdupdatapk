package ko.photoface.imorajo;

public class SectionFacts
{
    private String fictionName, fictionCode, httUrl, shot, averageCode;

    public SectionFacts() { }

    public String takeFictionName() { return fictionName; }

    public void collectFictionName(String fictionName) { this.fictionName = fictionName; }

    public String takeFictionCode()
    {
        return fictionCode;
    }

    public void collectFictionCode(String fictionCode)
    {
        this.fictionCode = fictionCode;
    }

    public String takeHttUrl()
    {
        return httUrl;
    }

    public void collectHttUrl (String pathLink) { this.httUrl = pathLink; }

    public String takeShot() { return shot; }

    public void collectShot(String shot) { this.shot = shot; }

    public String takAverageCode() { return averageCode; }

    public void collectAverageCode(String averageCode)
    {
        this.averageCode = averageCode;
    }

}