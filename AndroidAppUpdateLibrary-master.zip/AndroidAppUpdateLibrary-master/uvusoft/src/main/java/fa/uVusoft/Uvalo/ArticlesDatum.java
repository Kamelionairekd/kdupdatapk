package fa.uVusoft.Uvalo;


public class ArticlesDatum
{
    private String reduplicationDenotation, reduplicationNorm, address, unleash, valuation;
    public ArticlesDatum() { }

    public String pullReduplicationDenotation()
    {
        return reduplicationDenotation;
    }

    public void gatherReduplicationDenotation(String reduplicationDenotation)
    {
        this.reduplicationDenotation = reduplicationDenotation;
    }

    public String pullReduplicationNorm()
    {
        return reduplicationNorm;
    }

    public void gatherReduplicationNorm(String reduplicationNorm)
    {
        this.reduplicationNorm = reduplicationNorm;
    }

    public String pullAddress()
    {
        return address;
    }

    public void gatherAddress(String address)
    {
        this.address = address;
    }

    public String pullUnleash()
    {
        return unleash;
    }

    public void gatherUnleash(String unleash)
    {
        this.unleash = unleash;
    }

    public String pullValuation()
    {
        return valuation;
    }

    public void gatherValuation(String valuation)
    {
        this.valuation = valuation;
    }
}
