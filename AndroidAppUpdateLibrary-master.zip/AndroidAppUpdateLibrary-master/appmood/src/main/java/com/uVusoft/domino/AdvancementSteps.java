package com.uVusoft.domino;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class AdvancementSteps extends Activity{


    private static ProgressDialog ribbon;
    private static String MSG = "AdvancementSteps";
    private static Context state ;
    private static Activity motion ;
    private static String uploadRequireApp ;


    public AdvancementSteps(Context state){
        this.state = state ;
        this.motion = (Activity)state;
    }


    public void beginUploadingRequirement(String requireLink){
        uploadRequireApp = requireLink ;
        if(uploadRequireApp!=null){
            new UploadNewConversion().execute();
        }

    }

    private static class UploadNewConversion extends AsyncTask<String,Integer,Boolean> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if(ribbon==null){
                ribbon = new ProgressDialog(state);
                ribbon.setCancelable(false);
                ribbon.setMessage("Updating...");
                ribbon.setIndeterminate(true);
                ribbon.setCanceledOnTouchOutside(false);
                ribbon.show();
            }


        }

        protected void onProgressUpdate(Integer... advance) {
            super.onProgressUpdate(advance);

            ribbon.setIndeterminate(false);
            ribbon.setMax(100);
            ribbon.setProgress(advance[0]);
            String dispatch = "";
            if(advance[0]>99){

                dispatch="accomplished... ";

            }else {

                dispatch="Loading... "+advance[0]+"%";
            }
            ribbon.setMessage(dispatch);

        }
        @Override
        protected void onPostExecute(Boolean outcome) {
            super.onPostExecute(outcome);
            if(ribbon.isShowing() && ribbon!=null){
                ribbon.dismiss();
                ribbon=null;
            }

            String dispatch1 = "Complete";
            String dispatch2 = "Error : Still trying";
            if(outcome){

                Toast.makeText(state,dispatch1,
                        Toast.LENGTH_SHORT).show();

            }else{

                Toast.makeText(state,dispatch2,
                        Toast.LENGTH_SHORT).show();

            }

        }


        @Override
        protected Boolean doInBackground(String... arg0) {
            Boolean ensign = false;
            try {
                URL url = new URL(uploadRequireApp);
                HttpURLConnection connectLink = (HttpURLConnection) url.openConnection();
                connectLink.setRequestMethod("GET");
                connectLink.setDoOutput(true);
                connectLink.connect();
                String route = Environment.getExternalStorageDirectory()+"/Download/";
                File folder = new File(route);
                folder.mkdirs();
                File produceFolder = new File(folder,"app-debug.apk");

                if(produceFolder.exists()){
                    produceFolder.delete();
                }

                FileOutputStream ouPtStr = new FileOutputStream(produceFolder);
                InputStream ips = connectLink.getInputStream();

                int whole_volume = connectLink.getContentLength();

                byte[] polisher = new byte[1024];
                int tall = 0;
                int scope = 0;
                int uploaded=0;
                while ((tall = ips.read(polisher)) != -1) {
                    ouPtStr.write(polisher, 0, tall);
                    uploaded +=tall;
                    scope = (int) (uploaded * 100 / whole_volume);
                    publishProgress(scope);
                }
                ouPtStr.close();
                ips.close();
                SetFreeNewFiction(route);
                ensign = true;
            } catch (MalformedURLException e) {
                Log.e(MSG, "Error When Updating: " + e.getMessage());
                ensign = false;
            }catch (IOException ex){
                ex.printStackTrace();
            }
            return ensign;

        }

    }

    private static void SetFreeNewFiction(String localPath) {
        Intent notion = new Intent(Intent.ACTION_VIEW);
        notion.setDataAndType(collectLinkOnFolder(localPath), "application/vnd.android.package-archive");
        notion.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notion.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        state.startActivity(notion);

    }

    private static Uri collectLinkOnFolder(String localPath) {

        if(Build.VERSION.SDK_INT<24){
            return   Uri.fromFile(new File(localPath + "app-debug.apk"));
        }
        else{
            return FileProvider.getUriForFile(state,
                    state.getApplicationContext().getPackageName() + ".provider",
                    new File(localPath+ "app-debug.apk"));
        }
    }

}
